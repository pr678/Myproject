# Myproject
Analvsis of Twitter Bot Usage for Indian Political Issuer An analysis project for Involvement of Iwitter Bots in the intamous political CAA issue. It involvec building a Relevance Vector Machine based classifier based on former research guidelines anc analvzing data procured usine Twitter based APIs
